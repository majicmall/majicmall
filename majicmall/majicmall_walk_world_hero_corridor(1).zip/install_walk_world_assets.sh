\
    #!/usr/bin/env bash
    set -euo pipefail

    PROJECT_ROOT="${1:-/workspaces/majicmall}"
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    DEST="$PROJECT_ROOT/core/static/img"

    echo "Installing MajicMall Megaverse Walk World assets..."
    mkdir -p "$DEST"

    cp "$SCRIPT_DIR/walk_world_desktop.webp" "$DEST/walk_world_desktop.webp"
    cp "$SCRIPT_DIR/walk_world_mobile.webp" "$DEST/walk_world_mobile.webp"

    cd "$PROJECT_ROOT"

    if [[ -f ".venv/bin/activate" ]]; then
      # shellcheck disable=SC1091
      source .venv/bin/activate
    fi

    python manage.py check
    python manage.py collectstatic --noinput

    echo
    echo "Installed:"
    ls -lh \
      core/static/img/walk_world_desktop.webp \
      core/static/img/walk_world_mobile.webp

    echo
    echo "Walk World assets are ready."
    echo "Open: /walk-world/fashion-zone/"
